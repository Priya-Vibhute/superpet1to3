from django.db import models

# Create your models here.
# -----------------------------------------------------------
#                    Product Model
# -----------------------------------------------------------

class Product(models.Model):
    product_name=models.CharField(max_length=70,default="product name")
    product_description=models.TextField(default="description")
    product_price=models.PositiveIntegerField(default=0)
    product_brand=models.CharField(max_length=60,default="superpet")
    product_picture=models.ImageField(upload_to="products/",default="")

    def __str__(self):
        return self.product_name





